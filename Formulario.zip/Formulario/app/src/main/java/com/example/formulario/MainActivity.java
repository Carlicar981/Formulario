package com.example.formulario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Spinner seleccion;
    CheckBox seguro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button miBoton;
        String[]datos={"Posicion:","Delantero","Centrocampista","Defensa","Portero"};
        miBoton = (Button) findViewById(R.id.miBoton);
        miBoton.setOnClickListener(this);
        miBoton.setOnLongClickListener(this::onLongClick);
        seleccion =(Spinner) findViewById(R.id.seleccion);
        ArrayAdapter<String>adaptador=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,datos);
        seleccion.setAdapter(adaptador);
        seguro=(CheckBox)  findViewById(R.id.checkBox);

    }



    @Override
    public void onClick(View v) {
        TextView entradaNombre;
        TextView entradaNombre2;
        TextView entradaNumero;
        TextView salidaNombre;
        String selector=seleccion.getSelectedItem().toString();
        String posicion = "";
        if (selector.equals("Delantero")){
                posicion="Delantero";
        }else if (selector.equals("Centrocampista")){
            posicion="Centrocampista";
        }else if (selector.equals("Defensa")){
            posicion="Defensa";
        }else if (selector.equals("Portero")){
            posicion="Portero";
        }
        String pagoSeguro;
        if (seguro.isChecked()) {
           pagoSeguro="Si";
        }else{
            pagoSeguro="No";
        }


        entradaNombre = (TextView) findViewById(R.id.entradaTexto);
        entradaNombre2 = (TextView) findViewById(R.id.entradaTexto2);
        entradaNumero = (TextView) findViewById(R.id.entradaNumero);

        salidaNombre = (TextView) findViewById(R.id.salidaTexto);
        salidaNombre.setText("Nombre: " + entradaNombre.getText()+
                "\nApellidos: " + entradaNombre2.getText()+"\nEdad: "+entradaNumero.getText()+
                "\nPosicio: "+posicion+"\nPaga seguro: "+pagoSeguro);

    }
    public boolean onLongClick(View v) {
        TextView entradaNombre;
        TextView salidaNombre;



        entradaNombre = (TextView) findViewById(R.id.entradaTexto);
        salidaNombre = (TextView) findViewById(R.id.salidaTexto);
        salidaNombre.setText("Hola que tal " + entradaNombre.getText());
        return true;
    }


}